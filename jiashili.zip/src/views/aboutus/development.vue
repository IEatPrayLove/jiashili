/* 发展历程 */
<template>
  <div class="content_box">
    <Top :title="title" />
    <div class="time_box">
      <div class="time">
        <div class="xian"></div>
        <div class="point"></div>
        <div class="xian"></div>
        <div class="icon">
          <img src="../../assets/address.png" alt />
        </div>
        <div class="txt">2000年</div>
      </div>
      <div class="time">
        <div class="xian"></div>
        <div class="point"></div>
        <div class="xian"></div>
        <div class="icon">
          <img src="../../assets/address.png" alt />
        </div>
        <div class="txt">2000年</div>
      </div>
    </div>
    <swiper>
      <swiper-slide>未完待续</swiper-slide>
      <swiper-slide>Slide 2</swiper-slide>
      <swiper-slide>Slide 3</swiper-slide>
      <swiper-slide>Slide 4</swiper-slide>
      <swiper-slide>Slide 5</swiper-slide>
      <swiper-slide>Slide 6</swiper-slide>
      <swiper-slide>Slide 7</swiper-slide>
      <swiper-slide>Slide 8</swiper-slide>
      <swiper-slide>Slide 9</swiper-slide>
      <swiper-slide>Slide 10</swiper-slide>
    </swiper>
  </div>
</template>
<script>
import Top from "@/components/line";
export default {
  components: {
    Top
  },
  data() {
    return {
      title: {
        name: "DEVELOPMENT PATH",
        desc: "发展历程"
      }
    };
  }
};
</script>
<style lang="scss" scoped>
.content_box {
  background-color: #fff;
  height: 704px;
  .time_box {
    display: flex;
    .time {
      height: 100px;
      width: 200px;
      display: flex;
      align-items: center;
      position: relative;
      .xian {
        width: 96px;
        height: 1px;
        background-color: #a5a5a5;
      }
      .point {
        width: 8px;
        height: 8px;
        border: 1px solid #3a3a3a;
        opacity: 1;
      }
      .icon {
        position: absolute;
        top: 0;
        left: 86px;
      }
      .txt {
        width: 100%;
        position: absolute;
        bottom: 0;
        left: 0;
        text-align: center;
      }
    }
  }
}
</style>